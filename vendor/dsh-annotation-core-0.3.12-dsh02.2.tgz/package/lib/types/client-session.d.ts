import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** DSH 0.2 selection belongs to mainView retention; the catalog has no current field. */
export interface MainSessionSnapshot {
    readonly byId?: Readonly<Record<string, {
        readonly retainedBy?: Readonly<Record<string, number>>;
    } | undefined>>;
}
export declare function currentMainSession(snapshot: MainSessionSnapshot): string | undefined;
export interface MainSessionNavigation {
    readonly sessions: {
        readonly list: {
            getSnapshot(): MainSessionSnapshot;
            subscribe(listener: () => void): () => void;
        };
    };
    readonly uiWorkspace: {
        openSession(id: SessionId): void;
    };
}
/** Wait for the official asynchronous navigation to publish its selected owner. */
export declare function openMainSession(ctx: MainSessionNavigation, id: string, signal?: AbortSignal): Promise<void>;
//# sourceMappingURL=client-session.d.ts.map