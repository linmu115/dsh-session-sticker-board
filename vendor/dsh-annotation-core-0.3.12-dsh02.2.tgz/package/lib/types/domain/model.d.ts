import type { DshMessageLocator, ObsidianNoteLocator, ReferenceSource, SourceSnapshot } from '../protocol/index.ts';
import type { PreparedUpstreamContext } from './upstream-context.ts';
export declare const REFERENCE_SET_SCHEMA_VERSION: 1;
export type ReferenceSetState = 'pending' | 'committing' | 'sent' | 'failed';
export type BacklinkState = 'not-required' | 'pending' | 'written' | 'failed';
/** A relation locator only; no selected text, document snapshot or transcript. */
export interface ReferenceLinkSummary {
    readonly setId: string;
    readonly referenceId: string;
    readonly state: ReferenceSetState | 'deleted';
}
interface ReferenceItemBase {
    readonly referenceId: string;
    readonly number: number;
    readonly selectedText: string;
    readonly userComment: string;
    readonly backlinkState: BacklinkState;
}
export interface DshMessageReferenceItem extends ReferenceItemBase {
    readonly sourceType: 'dsh-message';
    readonly locator: DshMessageLocator;
    /** Host-prepared at send time; absent from unsent captures and older submissions. */
    readonly initialContext?: PreparedUpstreamContext | undefined;
}
export interface ObsidianNoteReferenceItem extends ReferenceItemBase {
    readonly sourceType: 'obsidian-note';
    readonly locator: ObsidianNoteLocator;
    readonly snapshot: SourceSnapshot;
}
export interface ExtensionReferenceItem extends ReferenceItemBase {
    readonly sourceType: 'extension';
    readonly locator: Extract<ReferenceSource, {
        sourceType: 'extension';
    }>['locator'];
    readonly snapshot: SourceSnapshot;
}
export type ReferenceItem = DshMessageReferenceItem | ObsidianNoteReferenceItem | ExtensionReferenceItem;
export interface ReferenceSet {
    readonly schemaVersion: typeof REFERENCE_SET_SCHEMA_VERSION;
    readonly setId: string;
    readonly profileId: string;
    readonly sessionId: string;
    readonly state: ReferenceSetState;
    readonly revision: number;
    readonly items: readonly ReferenceItem[];
    readonly createdAt: number;
    readonly committedAt?: number;
    readonly userMessageId?: string;
    readonly userAnchorId?: string;
    readonly userTextHash?: string;
}
export interface CreateReferenceSetInput {
    readonly setId: string;
    readonly profileId: string;
    readonly sessionId: string;
    readonly createdAt: number;
}
export interface AddReferenceInput {
    readonly referenceId: string;
    readonly source: ReferenceSource;
    readonly userComment?: string;
}
export interface CompleteReferenceCommitInput {
    readonly expectedRevision: number;
    readonly committedAt: number;
    readonly userMessageId: string;
    readonly userAnchorId: string;
    readonly userTextHash: string;
}
export interface ReuseReferenceInput {
    readonly setId: string;
    readonly referenceId: string;
    readonly targetSessionId: string;
    readonly createdAt: number;
}
export {};
//# sourceMappingURL=model.d.ts.map