import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
declare const valueSchema: z.ZodObject<{
    sessionId: z.ZodString;
    namespace: z.ZodString;
    objectId: z.ZodString;
    revision: z.ZodNumber;
    deleted: z.ZodBoolean;
    content: z.ZodJSONSchema;
}, z.core.$strict>;
export type SessionExtensionObject = z.infer<typeof valueSchema>;
export interface SessionExtensionData {
    readonly protocolVersion: 1;
    get(sessionId: string, namespace: string, objectId: string): SessionExtensionObject | undefined;
    list(namespace: string, sessionId?: string): SessionExtensionObject[];
    ready?(namespace: string, sessionId?: string): Promise<void>;
    write(input: Omit<SessionExtensionObject, 'revision'> & {
        expectedRevision: number;
    }): Promise<SessionExtensionObject>;
}
/** Structural consumer of the public session-extension-sync/v1 contract. */
export interface SessionExtensionSync {
    readonly protocolVersion: 1;
    readonly namespaces: readonly string[];
    read(namespace: string, sessionId?: string): Promise<readonly SessionExtensionObject[]>;
    commit(value: SessionExtensionObject): Promise<void>;
}
export interface SessionExtensionTable {
    get(key: string): SessionExtensionObject | undefined;
    entries(): IterableIterator<[string, SessionExtensionObject]>;
    put(key: string, value: SessionExtensionObject): Promise<unknown>;
    update(key: string, change: (value: SessionExtensionObject) => SessionExtensionObject): Promise<unknown>;
}
export declare const sessionExtensionsDomain: {
    name: string;
    version: number;
    tables: {
        objects: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            sessionId: string;
            namespace: string;
            objectId: string;
            revision: number;
            deleted: boolean;
            content: z.core.util.JSONType;
        }>;
    };
};
/** Host-owned session data. Consumers validate their business objects before writing. */
export declare class LocalSessionExtensionData implements SessionExtensionData {
    private readonly table;
    private readonly assertWritable;
    private readonly replica;
    readonly protocolVersion: 1;
    private tails;
    private syncTail;
    constructor(table: SessionExtensionTable, assertWritable?: () => Promise<void>, replica?: () => SessionExtensionSync | undefined);
    private transport;
    ready(namespace: string, sessionId?: string): Promise<void>;
    get(sessionId: string, namespace: string, objectId: string): {
        sessionId: string;
        namespace: string;
        objectId: string;
        revision: number;
        deleted: boolean;
        content: z.core.util.JSONType;
    } | undefined;
    list(namespace: string, sessionId?: string): {
        sessionId: string;
        namespace: string;
        objectId: string;
        revision: number;
        deleted: boolean;
        content: z.core.util.JSONType;
    }[];
    write(input: Omit<SessionExtensionObject, 'revision'> & {
        expectedRevision: number;
    }): Promise<SessionExtensionObject>;
    drain(): Promise<void>;
}
export declare class SessionExtensionStartupStoppedError extends Error {
    constructor();
}
export declare function openSessionExtensionData(ctx: Context, beforeClose?: () => Promise<void>, isClosing?: () => boolean): Promise<LocalSessionExtensionData>;
export {};
//# sourceMappingURL=session-extension-data.d.ts.map