import type { Agent } from '@deepseek-ai/dsh-agent';
export interface NativeUpstreamUsage {
    readonly executionId: string;
    readonly modelContextWindow: number;
    readonly inputTokens: number;
    readonly outputTokens: number;
}
/**
 * Headroom for on-demand upstream reads when the routed provider reports no
 * native usage. The context window is denominated in tokens, so the request's
 * JSON size must be converted before it is subtracted: counting raw UTF-8 bytes
 * as tokens overstates the conversation severalfold (a CJK character is about
 * one token but three bytes) and can zero the headroom in a session that still
 * has room. Bytes are priced at the host's own density, matching
 * `@deepseek-ai/dsh-token-meter`.
 */
export declare function upstreamHeadroom(contextWindow: number | undefined, request: unknown, maxTokens?: number): number;
/** The model never chooses its execution ID or allowance. Simultaneous calls reserve before awaiting. */
export declare class UpstreamToolBudgets {
    private readonly nativeUsageFor?;
    private readonly initialBytesFor?;
    private readonly turns;
    constructor(nativeUsageFor?: ((sessionId: string) => NativeUpstreamUsage | undefined) | undefined, initialBytesFor?: ((agent: Agent) => number) | undefined);
    reserve(agent: Agent, requested?: number): {
        executionId: string;
        bytes: number;
        totalBytes: number;
        settle(value?: string): void;
    };
    end(sessionId: string): string | undefined;
}
//# sourceMappingURL=upstream-budget.d.ts.map