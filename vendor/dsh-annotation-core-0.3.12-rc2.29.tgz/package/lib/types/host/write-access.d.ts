export interface SessionWriteContext {
    get(name: never): unknown;
    inject?(names: string[], callback: () => void): unknown;
}
export declare function observeSessionWriteAccess(ctx: SessionWriteContext): void;
export declare function assertSessionWritable(ctx: SessionWriteContext): Promise<void>;
//# sourceMappingURL=write-access.d.ts.map