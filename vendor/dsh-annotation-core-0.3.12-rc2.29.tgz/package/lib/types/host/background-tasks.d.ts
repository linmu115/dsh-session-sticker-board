/** Tracks admitted work so lifecycle cleanup can close its storage last. */
export declare class BackgroundTasks {
    private readonly active;
    private stopped;
    get closed(): boolean;
    run<T>(operation: () => Promise<T>): Promise<T>;
    dispose(): Promise<void>;
}
/** Preserve rejection while waiting for every sibling write, not only the first failure. */
export declare function settleAll(tasks: readonly Promise<unknown>[]): Promise<void>;
//# sourceMappingURL=background-tasks.d.ts.map