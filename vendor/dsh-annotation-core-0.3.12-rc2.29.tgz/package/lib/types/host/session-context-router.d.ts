import type { UpstreamHost } from './upstream.ts';
/** A removed managed provider never turns a running registered instance into an offline writer. */
export declare function sessionContextRouter(local: UpstreamHost, provider: () => UpstreamHost | undefined): UpstreamHost;
//# sourceMappingURL=session-context-router.d.ts.map