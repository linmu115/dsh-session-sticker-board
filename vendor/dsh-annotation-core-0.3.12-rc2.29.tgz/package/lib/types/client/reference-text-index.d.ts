/**
 * Shared, bounded text index for durable reference locators.
 *
 * Locators carry a quote + occurrence, never a character offset, so every paint
 * has to walk the message root and rebuild the non-whitespace character table.
 * Two surfaces now need the same table (CSS Highlight ranges and the inline
 * badge overlay), so the walk lives here and is cached per anchor root.
 *
 * The cache is deliberately process-local and short-lived: both surfaces call
 * `clearReferenceTextIndex()` at the start of a paint that a message-DOM batch
 * (or a store/scroll/resize change) scheduled, so a table is never served across
 * a layout change. Kept-out mutations are filtered by `affectsMessageText`, which
 * is what stops this plugin's own rendering from invalidating the tables. Keys are
 * element identities, so a dropped or re-rendered message simply stops being read.
 */
export interface ReferenceTextIndex {
    /** Non-whitespace characters of the root, in document order. */
    readonly chars: readonly {
        node: Text;
        offset: number;
        char: string;
    }[];
    /** The same characters joined; `chars` and `content` always agree in length. */
    readonly content: string;
}
/**
 * Attributes that can move message text without changing it: the sticker board
 * watches the same set, and a layout shift changes where a badge belongs even
 * though the characters are identical.
 */
export declare const LAYOUT_ATTRIBUTES: readonly string[];
/** Mark the tables stale; call from the mutation observer, never per paint. */
export declare function markReferenceTextDirty(): void;
/** Drop cached tables right now. Only needed when observation starts over. */
export declare function clearReferenceTextIndex(): void;
/**
 * True when a DOM mutation batch may have changed message text or moved it: at
 * least one record landed outside this plugin's own UI, and it either carried
 * content or touched one of {@link LAYOUT_ATTRIBUTES}. Callers use it both to
 * schedule a repaint and to mark the tables stale, which is what keeps this
 * plugin's own rendering (badge host, dialog host) from invalidating them.
 */
export declare function affectsMessageText(records: readonly MutationRecord[]): boolean;
export declare function referenceTextIndex(root: HTMLElement): ReferenceTextIndex;
/** Non-whitespace projection of a quote, matching the indexed character stream. */
export declare function normalizeReferenceText(text: string): string;
//# sourceMappingURL=reference-text-index.d.ts.map