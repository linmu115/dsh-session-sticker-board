import type { ReferenceItem } from '../domain/model.ts';
import { type SourceAdapterKey } from '../protocol/index.ts';
import type { ClientSourceAdapter } from '../public/client-api.ts';
export declare class ClientSourceRegistry {
    private readonly adapters;
    register(type: SourceAdapterKey, adapter: ClientSourceAdapter): () => void;
    get(type: SourceAdapterKey): ClientSourceAdapter | undefined;
    forItem(item: ReferenceItem): ClientSourceAdapter | undefined;
}
//# sourceMappingURL=source-registry.d.ts.map