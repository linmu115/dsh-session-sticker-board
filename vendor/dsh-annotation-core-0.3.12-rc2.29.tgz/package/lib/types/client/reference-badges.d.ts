import type { ReferenceItem, ReferenceSet } from '../domain/model.ts';
import { type ReferenceHighlightStore } from './reference-highlights.tsx';
export interface BadgePoint {
    readonly x: number;
    readonly y: number;
}
/** Only the geometry the collision band needs, so jsdom can fake a dot rect. */
export interface DotRect {
    readonly left: number;
    readonly top: number;
    readonly width: number;
    readonly height: number;
}
export interface ReferenceBadgeCandidate {
    readonly key: string;
    readonly anchorId: string;
    readonly occurrence: number;
    readonly set: ReferenceSet;
    readonly item: ReferenceItem;
}
/**
 * Merge the pending set with the already-prefetched sent sets.
 *
 * Deduplication uses the same identity as the CSS highlight pass
 * (`anchorId + selectedText + occurrence`), so a passage shows exactly one badge
 * no matter how many sent sets quote it. The whole `set` travels with the badge
 * because the click hands it to the dialog, which renders the set's other items
 * as tabs.
 */
export declare function collectReferenceBadges(store: ReferenceHighlightStore, sessionId: string | undefined): ReferenceBadgeCandidate[];
/**
 * Collision band used by the sticker board's own `spreadDotPoint` (|Δx| < 18,
 * |Δy| < 20), widened slightly.
 */
export declare function stickerDotRects(root?: ParentNode): DotRect[];
/**
 * Heuristic only: no cross-plugin agreement exists, the sticker board does not
 * know we are here, and it may move or skip its dots at any time. We simply step
 * down the same 24px ladder until the point clears the rectangles that are
 * visible right now. A missing or renamed sticker class degrades to "no
 * avoidance", which is exactly the pre-existing overlap.
 */
export declare function avoidStickerDots(point: BadgePoint, blocked: readonly DotRect[]): BadgePoint;
export interface ReferenceBadgesProps {
    readonly store: ReferenceHighlightStore;
    currentSession(): string | undefined;
    subscribeSession(listener: () => void): () => void;
    /** Durable anchorId → rendered `[data-chat-anchor-key]` value. */
    resolveAnchor(item: ReferenceItem): string;
    /** Default placement: the dialog docks to the composer card by itself. */
    openReference(set: ReferenceSet, referenceId?: string): void;
}
export declare function ReferenceBadges({ store, currentSession, subscribeSession, resolveAnchor, openReference }: ReferenceBadgesProps): import("react").JSX.Element;
//# sourceMappingURL=reference-badges.d.ts.map