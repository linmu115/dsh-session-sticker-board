import { Service } from '@deepseek-ai/cordis';
import { InputAcceptanceRegistry } from './input-acceptance.ts';
import type { Context } from '@deepseek-ai/cordis';
import type { ReferenceItem } from '../domain/model.ts';
import type { BacklinkReceiptV2 } from '../protocol/index.ts';
import type { SourceType } from '../protocol/index.ts';
import type { AnnotationCoreHost, DeletedReferenceBinding, HostSourceAdapter, SentReferenceBinding } from '../public/host-api.ts';
export type SourcePreparationErrorCode = 'offline' | 'online-refresh-failed' | 'source-missing' | 'source-changed' | 'protocol-mismatch';
export interface HostSourceRegistryOptions {
    readonly listReferences?: NonNullable<AnnotationCoreHost['listReferences']>;
    readonly deleteReferenceLink?: (sessionId: string, setId: string, referenceId: string) => Promise<{
        deleted: boolean;
        scope: 'pending' | 'sent';
    }>;
}
export declare class SourcePreparationError extends Error {
    readonly code: SourcePreparationErrorCode;
    constructor(code: SourcePreparationErrorCode, message: string, options?: ErrorOptions);
}
export declare class HostSourceRegistry extends Service implements AnnotationCoreHost {
    private readonly options;
    readonly inputAcceptance: InputAcceptanceRegistry;
    private readonly adapters;
    private readonly adapterListeners;
    constructor(ctx: Context, options?: HostSourceRegistryOptions);
    listReferences(...args: Parameters<NonNullable<AnnotationCoreHost['listReferences']>>): readonly import("../domain/model.ts").ReferenceSet[];
    deleteReferenceLink(sessionId: string, setId: string, referenceId: string): Promise<{
        deleted: boolean;
        scope: 'pending' | 'sent';
    }>;
    registerSourceAdapter(type: SourceType, adapter: HostSourceAdapter): () => void;
    onAdapterRegistered(listener: (type: SourceType) => void): () => void;
    require(type: SourceType): HostSourceAdapter;
    get(type: SourceType): HostSourceAdapter | undefined;
    prepare(item: ReferenceItem, signal: AbortSignal): Promise<ReferenceItem>;
    discardPending(item: ReferenceItem): Promise<void>;
    commitBacklink(binding: SentReferenceBinding): Promise<BacklinkReceiptV2 | undefined>;
    deleteCommitted(binding: DeletedReferenceBinding): Promise<void>;
}
//# sourceMappingURL=source-registry.d.ts.map