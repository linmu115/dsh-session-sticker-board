import type { ReferenceSet } from '../domain/model.ts';
import type { ReferenceSessionStore } from './composer-binding.tsx';
export interface ReferenceRailProps {
    readonly layout: 'default' | 'narrow';
    readonly store: ReferenceSessionStore;
    readonly open: (set: ReferenceSet, referenceId?: string) => void;
    readonly remove: (referenceId: string) => Promise<void>;
}
export declare function ReferenceRail({ layout, store, open, remove }: ReferenceRailProps): import("react").JSX.Element | null;
//# sourceMappingURL=reference-rail.d.ts.map