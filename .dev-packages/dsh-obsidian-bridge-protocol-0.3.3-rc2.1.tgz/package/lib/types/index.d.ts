import { z } from "zod";
export declare const BRIDGE_LIFECYCLE_PROTOCOL_VERSION: 3;
export declare const bridgeBrowserOriginSchema: z.ZodString;
export type BridgeBrowserOrigin = z.infer<typeof bridgeBrowserOriginSchema>;
export declare const bridgeBrowserOriginsSchema: z.ZodArray<z.ZodString>;
export declare const bridgeDshViewerUrlSchema: z.ZodString;
export type BridgeDshViewerUrl = z.infer<typeof bridgeDshViewerUrlSchema>;
export declare const bridgeLifecycleStateSchema: z.ZodEnum<{
    STARTING: "STARTING";
    READY: "READY";
    DEGRADED: "DEGRADED";
    DRAINING: "DRAINING";
    DRAINED: "DRAINED";
    OFFLINE: "OFFLINE";
}>;
export type BridgeLifecycleState = z.infer<typeof bridgeLifecycleStateSchema>;
export declare const bridgeClientRoleSchema: z.ZodEnum<{
    controller: "controller";
    surface: "surface";
}>;
export type BridgeClientRole = z.infer<typeof bridgeClientRoleSchema>;
export declare const bridgeIdentitySchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    instanceId: z.ZodString;
    bootId: z.ZodString;
    bridgeVersion: z.ZodString;
    startedAt: z.ZodNumber;
}, z.core.$strip>;
export type BridgeIdentity = z.infer<typeof bridgeIdentitySchema>;
export declare const bridgeLeaseSchema: z.ZodObject<{
    leaseId: z.ZodString;
    clientId: z.ZodString;
    role: z.ZodEnum<{
        controller: "controller";
        surface: "surface";
    }>;
    bootId: z.ZodString;
    acquiredAt: z.ZodNumber;
    expiresAt: z.ZodNumber;
    browserOrigins: z.ZodArray<z.ZodString>;
    dshViewerUrl: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type BridgeLease = z.infer<typeof bridgeLeaseSchema>;
export declare const bridgeStatusSchema: z.ZodObject<{
    state: z.ZodEnum<{
        STARTING: "STARTING";
        READY: "READY";
        DEGRADED: "DEGRADED";
        DRAINING: "DRAINING";
        DRAINED: "DRAINED";
    }>;
    stateChangedAt: z.ZodNumber;
    activeLeaseCount: z.ZodNumber;
    inFlightRequestCount: z.ZodNumber;
    degradedReason: z.ZodOptional<z.ZodString>;
    drainRequestId: z.ZodOptional<z.ZodString>;
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    instanceId: z.ZodString;
    bootId: z.ZodString;
    bridgeVersion: z.ZodString;
    startedAt: z.ZodNumber;
}, z.core.$strip>;
export type BridgeStatus = z.infer<typeof bridgeStatusSchema>;
export declare const bridgeOfflineStatusSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    state: z.ZodLiteral<"OFFLINE">;
    stateChangedAt: z.ZodNumber;
    lastKnownIdentity: z.ZodOptional<z.ZodObject<{
        lifecycleProtocolVersion: z.ZodLiteral<3>;
        instanceId: z.ZodString;
        bootId: z.ZodString;
        bridgeVersion: z.ZodString;
        startedAt: z.ZodNumber;
    }, z.core.$strip>>;
    reason: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type BridgeOfflineStatus = z.infer<typeof bridgeOfflineStatusSchema>;
export type ObservedBridgeStatus = BridgeStatus | BridgeOfflineStatus;
export declare const bridgeControlHandshakeRequestSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    clientId: z.ZodString;
    role: z.ZodEnum<{
        controller: "controller";
        surface: "surface";
    }>;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    expectedBootId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type BridgeControlHandshakeRequest = z.infer<typeof bridgeControlHandshakeRequestSchema>;
export declare const bridgeControlHandshakeResponseSchema: z.ZodObject<{
    clientId: z.ZodString;
    role: z.ZodEnum<{
        controller: "controller";
        surface: "surface";
    }>;
    token: z.ZodString;
    tokenExpiresAt: z.ZodNumber;
    state: z.ZodEnum<{
        STARTING: "STARTING";
        READY: "READY";
        DEGRADED: "DEGRADED";
        DRAINING: "DRAINING";
        DRAINED: "DRAINED";
    }>;
    stateChangedAt: z.ZodNumber;
    activeLeaseCount: z.ZodNumber;
    inFlightRequestCount: z.ZodNumber;
    degradedReason: z.ZodOptional<z.ZodString>;
    drainRequestId: z.ZodOptional<z.ZodString>;
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    instanceId: z.ZodString;
    bootId: z.ZodString;
    bridgeVersion: z.ZodString;
    startedAt: z.ZodNumber;
}, z.core.$strip>;
export type BridgeControlHandshakeResponse = z.infer<typeof bridgeControlHandshakeResponseSchema>;
export declare const acquireBridgeLeaseRequestSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    expectedBootId: z.ZodString;
    ttlMs: z.ZodNumber;
    browserOrigins: z.ZodArray<z.ZodString>;
    dshViewerUrl: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type AcquireBridgeLeaseRequest = z.infer<typeof acquireBridgeLeaseRequestSchema>;
export declare const renewBridgeLeaseRequestSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    expectedBootId: z.ZodString;
    ttlMs: z.ZodNumber;
    browserOrigins: z.ZodArray<z.ZodString>;
    dshViewerUrl: z.ZodOptional<z.ZodString>;
    leaseId: z.ZodString;
}, z.core.$strip>;
export type RenewBridgeLeaseRequest = z.infer<typeof renewBridgeLeaseRequestSchema>;
export declare const drainBridgeRequestSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    requestId: z.ZodString;
    expectedBootId: z.ZodString;
    deadlineMs: z.ZodNumber;
    reason: z.ZodString;
}, z.core.$strip>;
export type DrainBridgeRequest = z.infer<typeof drainBridgeRequestSchema>;
export declare const resumeBridgeRequestSchema: z.ZodObject<{
    lifecycleProtocolVersion: z.ZodLiteral<3>;
    requestId: z.ZodString;
    expectedBootId: z.ZodString;
}, z.core.$strip>;
export type ResumeBridgeRequest = z.infer<typeof resumeBridgeRequestSchema>;
export declare const bridgeControlErrorSchema: z.ZodObject<{
    error: z.ZodString;
    code: z.ZodOptional<z.ZodEnum<{
        BOOT_MISMATCH: "BOOT_MISMATCH";
        NOT_CONTROLLER: "NOT_CONTROLLER";
        INVALID_STATE: "INVALID_STATE";
        LEASE_NOT_FOUND: "LEASE_NOT_FOUND";
        PROTOCOL_MISMATCH: "PROTOCOL_MISMATCH";
    }>>;
}, z.core.$strip>;
export type BridgeControlError = z.infer<typeof bridgeControlErrorSchema>;
export declare function isBridgeOnline(status: ObservedBridgeStatus): status is BridgeStatus;
export declare function acceptsBridgeWork(status: ObservedBridgeStatus): status is BridgeStatus;
