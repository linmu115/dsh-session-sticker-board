import { z } from "zod";
/** Data-plane schemas remain separate from control roles, leases and runtime I/O. */
export declare const STICKER_PROTOCOL_VERSION: 1;
export declare const PROTOCOL_VERSION: 1;
export declare const stableLogicalTargetShape: {
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
};
export declare const stickerSchema: z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    role: z.ZodEnum<{
        user: "user";
        assistant: "assistant";
    }>;
    quote: z.ZodString;
    quoteHash: z.ZodString;
    occurrence: z.ZodNumber;
    markdown: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    color: z.ZodEnum<{
        yellow: "yellow";
        green: "green";
        pink: "pink";
        blue: "blue";
    }>;
    notePath: z.ZodOptional<z.ZodString>;
    blockId: z.ZodOptional<z.ZodString>;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    stickerId: z.ZodString;
}, z.core.$strip>;
export declare const deepLinkActionSchema: z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    quoteHash: z.ZodOptional<z.ZodString>;
    stickerId: z.ZodOptional<z.ZodString>;
    setId: z.ZodOptional<z.ZodString>;
    referenceId: z.ZodOptional<z.ZodString>;
    targetSurfaceId: z.ZodOptional<z.ZodString>;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"deep-link">;
    actionId: z.ZodString;
}, z.core.$strip>;
export declare const openNoteActionSchema: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"open-note">;
    actionId: z.ZodString;
    notePath: z.ZodString;
    blockId: z.ZodOptional<z.ZodString>;
    line: z.ZodOptional<z.ZodNumber>;
    column: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const stickerBacklinkTargetSchema: z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    quoteHash: z.ZodString;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    stickerId: z.ZodString;
}, z.core.$strip>;
export declare const stickerBacklinkSchema: z.ZodObject<{
    notePath: z.ZodString;
    line: z.ZodNumber;
    column: z.ZodOptional<z.ZodNumber>;
    blockId: z.ZodOptional<z.ZodString>;
    heading: z.ZodOptional<z.ZodString>;
    excerpt: z.ZodString;
}, z.core.$strip>;
export declare const stickerBacklinkDeleteResultSchema: z.ZodObject<{
    notesChanged: z.ZodNumber;
    linksRemoved: z.ZodNumber;
}, z.core.$strip>;
export declare const pendingCitationSchema: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"pending-citation">;
    citationId: z.ZodString;
    notePath: z.ZodString;
    blockId: z.ZodString;
    heading: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
    contentHash: z.ZodString;
}, z.core.$strip>;
export declare const resolvedCitationSchema: z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    role: z.ZodLiteral<"user">;
    quoteHash: z.ZodString;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"resolved-citation">;
    citationId: z.ZodString;
}, z.core.$strip>;
export declare const sessionNoteDocumentSchema: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"session-note">;
    sessionId: z.ZodString;
    revision: z.ZodString;
    stickers: z.ZodArray<z.ZodObject<{
        sessionId: z.ZodString;
        anchorId: z.ZodString;
        role: z.ZodEnum<{
            user: "user";
            assistant: "assistant";
        }>;
        quote: z.ZodString;
        quoteHash: z.ZodString;
        occurrence: z.ZodNumber;
        markdown: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        color: z.ZodEnum<{
            yellow: "yellow";
            green: "green";
            pink: "pink";
            blue: "blue";
        }>;
        notePath: z.ZodOptional<z.ZodString>;
        blockId: z.ZodOptional<z.ZodString>;
        dshInstanceId: z.ZodOptional<z.ZodString>;
        logicalSessionId: z.ZodOptional<z.ZodString>;
        logicalAnchorId: z.ZodOptional<z.ZodString>;
        legacySessionId: z.ZodOptional<z.ZodString>;
        legacyAnchorId: z.ZodOptional<z.ZodString>;
        stickerId: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const bridgeMessageSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    quoteHash: z.ZodOptional<z.ZodString>;
    stickerId: z.ZodOptional<z.ZodString>;
    setId: z.ZodOptional<z.ZodString>;
    referenceId: z.ZodOptional<z.ZodString>;
    targetSurfaceId: z.ZodOptional<z.ZodString>;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"deep-link">;
    actionId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"open-note">;
    actionId: z.ZodString;
    notePath: z.ZodString;
    blockId: z.ZodOptional<z.ZodString>;
    line: z.ZodOptional<z.ZodNumber>;
    column: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>, z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"pending-citation">;
    citationId: z.ZodString;
    notePath: z.ZodString;
    blockId: z.ZodString;
    heading: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
    contentHash: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    sessionId: z.ZodString;
    anchorId: z.ZodString;
    role: z.ZodLiteral<"user">;
    quoteHash: z.ZodString;
    dshInstanceId: z.ZodOptional<z.ZodString>;
    logicalSessionId: z.ZodOptional<z.ZodString>;
    logicalAnchorId: z.ZodOptional<z.ZodString>;
    legacySessionId: z.ZodOptional<z.ZodString>;
    legacyAnchorId: z.ZodOptional<z.ZodString>;
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"resolved-citation">;
    citationId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    type: z.ZodLiteral<"session-note">;
    sessionId: z.ZodString;
    revision: z.ZodString;
    stickers: z.ZodArray<z.ZodObject<{
        sessionId: z.ZodString;
        anchorId: z.ZodString;
        role: z.ZodEnum<{
            user: "user";
            assistant: "assistant";
        }>;
        quote: z.ZodString;
        quoteHash: z.ZodString;
        occurrence: z.ZodNumber;
        markdown: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        color: z.ZodEnum<{
            yellow: "yellow";
            green: "green";
            pink: "pink";
            blue: "blue";
        }>;
        notePath: z.ZodOptional<z.ZodString>;
        blockId: z.ZodOptional<z.ZodString>;
        dshInstanceId: z.ZodOptional<z.ZodString>;
        logicalSessionId: z.ZodOptional<z.ZodString>;
        logicalAnchorId: z.ZodOptional<z.ZodString>;
        legacySessionId: z.ZodOptional<z.ZodString>;
        legacyAnchorId: z.ZodOptional<z.ZodString>;
        stickerId: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>], "type">;
export type StickerRecord = z.infer<typeof stickerSchema>;
export type DeepLinkAction = z.infer<typeof deepLinkActionSchema>;
export type OpenNoteAction = z.infer<typeof openNoteActionSchema>;
export type StickerBacklinkTarget = z.infer<typeof stickerBacklinkTargetSchema>;
export type StickerBacklink = z.infer<typeof stickerBacklinkSchema>;
export type StickerBacklinkDeleteResult = z.infer<typeof stickerBacklinkDeleteResultSchema>;
export type PendingCitation = z.infer<typeof pendingCitationSchema>;
export type ResolvedCitation = z.infer<typeof resolvedCitationSchema>;
export type SessionNoteDocument = z.infer<typeof sessionNoteDocumentSchema>;
export type BridgeMessage = z.infer<typeof bridgeMessageSchema>;
export declare function parseBridgeMessage(value: unknown): BridgeMessage;
