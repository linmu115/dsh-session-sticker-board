/** Bounds headers and body reads, including fetch implementations that ignore abort. */
export declare function createRequestScope(fetchImpl: typeof fetch, timeoutMs?: number): {
    abort(): void;
    request(url: string, init?: RequestInit): Promise<Response>;
};
