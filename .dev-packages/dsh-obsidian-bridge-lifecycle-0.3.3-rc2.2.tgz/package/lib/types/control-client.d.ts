import { type BridgeClientRole, type BridgeLease, type BridgeStatus } from "dsh-obsidian-bridge-protocol";
export interface BridgeControlClientOptions {
    origin: string;
    clientId: string;
    role: BridgeClientRole;
    dshInstanceId?: string;
    fetch?: typeof globalThis.fetch;
    requestOrigin?: string;
    requestTimeoutMs?: number;
}
export interface BridgeControlClient {
    readonly origin: string;
    status(): Promise<BridgeStatus>;
    acquireLease(ttlMs: number, browserOrigins: readonly string[], dshViewerUrl?: string): Promise<BridgeLease>;
    renewLease(ttlMs: number, browserOrigins: readonly string[], dshViewerUrl?: string): Promise<BridgeLease>;
    releaseLease(): Promise<void>;
    drain(reason: string, deadlineMs: number): Promise<BridgeStatus>;
    resume(): Promise<BridgeStatus>;
    cancelPending(): void;
    dispose(): Promise<void>;
}
export declare function normalizeBridgeOrigin(value: string): string;
export declare function createBridgeControlClient(options: BridgeControlClientOptions): BridgeControlClient;
