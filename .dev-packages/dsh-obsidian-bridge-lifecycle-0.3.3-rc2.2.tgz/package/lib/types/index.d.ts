import { TypertRemoteService } from "@deepseek-ai/dsh-typert-protocol";
import { type Context } from "@deepseek-ai/cordis";
import s from "@deepseek-ai/schemastery";
import type { ObsidianBridgeLifecycle, BridgeRuntimeIdentity } from "./api.ts";
export * from "./api.ts";
export { BridgeLifecycleRuntime } from "./runtime.ts";
export declare const name = "dsh-obsidian-bridge-lifecycle";
export declare const inject: readonly ["webServer", "connection"];
interface WebServerBinding {
    readonly host: "127.0.0.1" | "0.0.0.0";
    readonly port: number;
}
export declare function browserOriginFromWebServer(server: WebServerBinding): string;
export declare function waitForBrowserOrigin(server: WebServerBinding, timeoutMs?: number, now?: () => number, wait?: (delayMs: number) => Promise<void>, signal?: AbortSignal): Promise<string>;
export interface Config {
    bridgeOrigin: string;
    dshInstanceId?: string;
    profileId?: string;
}
export declare const Config: s<Schemastery.ObjectS<{
    dshInstanceId: s<string, string>;
    profileId: s<string, string>;
    bridgeOrigin: s<string, string>;
}>, Schemastery.ObjectT<{
    dshInstanceId: s<string, string>;
    profileId: s<string, string>;
    bridgeOrigin: s<string, string>;
}>>;
export declare class BridgeLifecycleService extends TypertRemoteService implements ObsidianBridgeLifecycle {
    private readonly runtime;
    readonly runtimeIdentity: BridgeRuntimeIdentity;
    constructor(ctx: Context, config: Config);
    getBridgeConfig(): {
        origin: string;
        runtimeIdentity: BridgeRuntimeIdentity;
    };
    getHealth: () => import("./api.ts").BridgeLifecycleHealth;
    registerHealthSource: NonNullable<ObsidianBridgeLifecycle["registerHealthSource"]>;
    retry: (name?: string) => void;
    get bridgeOrigin(): string;
    getSnapshot: () => import("dsh-obsidian-bridge-protocol").ObservedBridgeStatus;
    subscribe: (listener: () => void) => () => void;
    mountWhenReady: ObsidianBridgeLifecycle["mountWhenReady"];
    drain: (reason: string, deadlineMs?: number) => Promise<void>;
    resume: () => Promise<void>;
}
export declare function apply(ctx: Context, config: Config): void;
