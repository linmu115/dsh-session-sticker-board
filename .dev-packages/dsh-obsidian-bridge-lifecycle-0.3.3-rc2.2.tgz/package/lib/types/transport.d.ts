import { type BacklinkCommitV2, type BacklinkReceiptV2, type ObsidianReferenceCaptureV2, type ReferenceClaimV2, type ReferenceRefreshResultV2, type ReferenceDeleteCommitV2, type ReferenceDeleteRequestV2 } from "dsh-annotation-core/protocol";
import { type DeepLinkAction, type OpenNoteAction, type SessionNoteDocument, type StickerBacklink, type StickerBacklinkDeleteResult, type StickerRecord } from "dsh-obsidian-bridge-protocol/data";
export type BridgeErrorCode = "source-changed" | "revision-conflict" | "idempotency-conflict" | "note-not-found" | "protocol-mismatch" | "http-error";
export declare class BridgeHttpError extends Error {
    readonly status: number;
    readonly code: BridgeErrorCode;
    constructor(status: number, code: BridgeErrorCode, message: string);
}
export declare class BridgeUnavailableError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
export type BridgeAction = DeepLinkAction | ObsidianReferenceCaptureV2 | ReferenceDeleteRequestV2;
export interface QueuedBridgeAction {
    cursor: number;
    message: BridgeAction;
}
export interface BridgeActionPage {
    queueId?: string;
    cursor: number;
    actions: readonly QueuedBridgeAction[];
}
export interface BridgeHttpClientOptions {
    origin: string;
    fetch?: typeof globalThis.fetch;
    now?: () => number;
    clientId?: string;
    surfaceId?: string;
    dshInstanceId?: string;
    requestOrigin?: string;
    requestTimeoutMs?: number;
}
export interface BridgeHttpClient {
    readonly origin: string;
    preflight(): Promise<void>;
    nextActions(after: number, signal?: AbortSignal): Promise<BridgeActionPage>;
    acknowledgeDeepLink(actionId: string, signal?: AbortSignal): Promise<void>;
    acknowledgeAction(actionId: string, signal?: AbortSignal): Promise<void>;
    claimReference(actionId: string, claim: ReferenceClaimV2, signal?: AbortSignal): Promise<void>;
    refreshReference(referenceId: string, knownDocumentHash: string, signal?: AbortSignal): Promise<ReferenceRefreshResultV2>;
    discardReference(referenceId: string): Promise<void>;
    commitBacklink(commit: BacklinkCommitV2): Promise<BacklinkReceiptV2>;
    deleteCommittedReference(commit: ReferenceDeleteCommitV2): Promise<void>;
    readSessionNote(sessionId: string): Promise<SessionNoteDocument>;
    saveSessionNote(document: SessionNoteDocument, expectedRevision: string): Promise<{
        revision: string;
    }>;
    openNote(action: OpenNoteAction): Promise<void>;
    listBacklinks(sticker: StickerRecord): Promise<StickerBacklink[]>;
    deleteStickerBacklinks(sticker: StickerRecord): Promise<StickerBacklinkDeleteResult>;
    dispose(): void;
}
export declare function normalizeBridgeOrigin(value: string): string;
export declare const DSH_BRIDGE_SURFACE_PARAMETER = "dshBridgeSurface";
export declare function bridgeSurfaceIdFromUrl(value: string): string | undefined;
export declare function createBridgeHttpClient(options: BridgeHttpClientOptions): BridgeHttpClient;
