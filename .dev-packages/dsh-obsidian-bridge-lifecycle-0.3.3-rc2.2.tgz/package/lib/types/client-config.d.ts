import type { BridgeRuntimeIdentity } from "./api.ts";
export declare function mountBridgeConfig(ctx: {
    get(name: string): unknown;
}): Promise<{
    origin: string;
    runtimeIdentity?: BridgeRuntimeIdentity;
    dispose(): Promise<void>;
}>;
